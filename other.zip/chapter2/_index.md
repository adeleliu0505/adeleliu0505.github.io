---
title: "Chapter 2 (weighted)"
date: 2017-10-17T15:26:15Z
draft: false
weight: 30
---

{{% panel status="primary" title="Note" icon="far fa-lightbulb" %}}
The `weight` field with weight number in your content’s front matter will render a weighted menu.

```
weight: 30
```

Lower weight gets higher precedence. So content with lower weight will come first.

{{% /panel %}}

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
